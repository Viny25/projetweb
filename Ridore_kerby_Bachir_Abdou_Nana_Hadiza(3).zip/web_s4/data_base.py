import sqlite3
from werkzeug.security import generate_password_hash

DBFILENAME = 'db.sqlite'


def db_run(query, args=(), db_name=DBFILENAME):
    with sqlite3.connect(db_name) as conn:
        conn.execute('PRAGMA foreign_keys = ON;')
        cur = conn.execute(query, args)
        conn.commit()


def create_tables():
    db_run('DROP TABLE IF EXISTS items')  # Supprimer d'abord la table items
    db_run('DROP TABLE IF EXISTS users')  # Puis supprimer la table users

    db_run(
        'CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, password TEXT NOT NULL, '
        'mail TEXT NOT NULL)')
    db_run(
        'CREATE TABLE items (id INTEGER PRIMARY KEY AUTOINCREMENT, description TEXT NOT NULL, condition TEXT NOT '
        'NULL, img_url TEXT NOT NULL, location TEXT NOT NULL, user_id INTEGER NOT NULL, FOREIGN KEY (user_id) '
        'REFERENCES users(id))')


create_tables()
