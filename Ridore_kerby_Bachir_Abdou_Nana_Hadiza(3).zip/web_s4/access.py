import sqlite3

from flask import session
from werkzeug.security import generate_password_hash, check_password_hash

DBFILENAME = 'db.sqlite'


# code issue du TP7
def db_fetch(query, args=(), all=False, db_name=DBFILENAME):
    with sqlite3.connect(db_name) as conn:
        # to allow access to columns by name in res
        conn.row_factory = sqlite3.Row
        cur = conn.execute(query, args)
        # convert to a python dictionary for convenience
        if all:
            res = cur.fetchall()
            if res:
                res = [dict(e) for e in res]
            else:
                res = []
        else:
            res = cur.fetchone()
            if res:
                res = dict(res)
    return res


def db_insert(query, args=(), db_name=DBFILENAME):
    with sqlite3.connect(db_name) as conn:
        cur = conn.execute(query, args)
        conn.commit()
        return cur.lastrowid


def db_run(query, args=(), db_name=DBFILENAME):
    with sqlite3.connect(db_name) as conn:
        conn.execute('PRAGMA foreign_keys = ON;')
        cur = conn.execute(query, args)
        conn.commit()


def db_update(query, args=(), db_name=DBFILENAME):
    with sqlite3.connect(db_name) as conn:
        cur = conn.execute(query, args)
        conn.commit()
        return cur.rowcount


def db_delete(query, args=(), db_name=DBFILENAME):
    with sqlite3.connect(db_name) as conn:
        cur = conn.execute(query, args)
        conn.commit()
        return cur.rowcount


def create_user(name, password, mail):
    existing_user = db_fetch('SELECT id FROM users WHERE name =?', (name,))
    if existing_user:
        return "User already exists"
    else:
        password_hash = generate_password_hash(password)
        user_id = db_insert('INSERT INTO  users (name, password, mail) VALUES (?,?,?)',
                            (name, password_hash, mail))
        return user_id


def delete_user():
    user_id = session.get('user_id')
    user_deleted = db_delete('DELETE FROM users WHERE id = ?', (user_id,))
    if user_deleted > 0:
        session.pop('user_id')  # Supprime également l'ID de l'utilisateur de la session
        return "Votre compte a été supprimé"
    else:
        return "Votre compte n'a pas été supprimé"


def update_user(user_id, name=None, password=None):
    user_id = session.get('user_id')
    if user_id is not None:
        if password is None and name is None:
            return "Vous devez fournir au moins un champ à mettre à jour"

        query = 'UPDATE users SET '
        params = []
        if name is not None:
            query += 'name = ?, '
            params.append(name)
        if password is not None:
            password_hash = generate_password_hash(password)
            query += 'password = ?, '
            params.append(password_hash)

        # Supprimer la dernière virgule et l'espace
        query = query[:-2]

        query += ' WHERE id = ?'
        params.append(user_id)

        db_update(query, tuple(params))
        return "Vos informations ont été mises à jour avec succès"
    else:
        return "Aucune information n'a ete mis a jour"


def create_item(description, condition, img_url, location):
    user_id = session.get('user_id')
    item_id = db_insert('INSERT INTO items (description, condition, img_url, location, user_id) VALUES (?, ?, ?, ?, ?)',
                        (description, condition, img_url, location, user_id))
    if item_id:
        return "Nouvel article créé avec succès"
    else:
        return "Erreur lors de la création de l'article"


def delete_item(item_id):
    user_id = session.get('user_id')
    item_deleted = db_delete('DELETE FROM items WHERE id = ? AND user_id = ?', (item_id, user_id))
    if item_deleted > 0:
        return "Don supprimé"
    else:
        return "Erreur : Vous n'êtes pas autorisé à supprimer cet article"


def list_item():
    items_list = db_fetch('SELECT * FROM items ORDER by id', all=True)
    return items_list


def login(user, password):
    result = db_fetch('SELECT id, password FROM users WHERE name = ?', (user,))
    if result is None:
        return -1
    elif not (check_password_hash(result['password'], password)):
        return -1
    else:
        return result['id']


def get_item_owner(item_id):
    # Effectuer une requête à la base de données pour récupérer l'ID du propriétaire de l'article
    item = db_fetch('SELECT user_id FROM items WHERE id = ?', (item_id,))
    if item:
        return item['user_id']
    else:
        return None

def get_user_email(name):
    user_email = db_fetch('SELECT mail FROM users WHERE name = ?', (name,))
    if user_email:
        return user_email[0]
    else:
        return None


def get_user_password(password):
    user_password = db_fetch('SELECT password FROM users WHERE password = ?', (password,))
    if user_password:
        return user_password[0]
    else:
        return None



