from flask import Flask, session, Response, request, redirect, url_for, render_template, send_from_directory, flash
import os
from werkzeug.utils import secure_filename
import sqlite3
#from flask_mail import Mail, Message

import access
from functools import wraps

app = Flask(__name__, static_url_path='/static')

app.secret_key = b'71e87c087e3f2d68d2fa13be6f11b368513e2fabf2be175059d60329e75c3240b'

# Configuration de Flask-Mail
app.config['MAIL_SERVER'] = 'smtp.example.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USERNAME'] = 'votre_email@example.com'
app.config['MAIL_PASSWORD'] = 'votre_mot_de_passe'
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USE_SSL'] = False

#mail = Mail(app)

UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Définir les extensions de fichiers autorisées
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not ('user_id' in session):
            return Response("Une connexion est requise", status=401)
        else:
            return f(*args, **kwargs)

    return decorated_function


@app.get('/')
def home():
    items = access.list_item()
    return render_template('index.html', items=items)


@app.get('/login')
def login_form():
    return render_template('login.html')


@app.post('/login')
def login_post():
    if request.method == 'POST':
        user = request.form['name']
        password = request.form['password']
        user_id = access.login(user, password)
        if user_id != -1:
            session['user_id'] = user_id  # Enregistrer l'ID de l'utilisateur dans la session
            return redirect('/')
        else:
            return render_template('login.html', error="Nom d'utilisateur ou mot de passe incorrect")


@app.get('/new_user')
def new_user_form():
    return render_template('new_user.html')


@app.post('/new_user')
def new_user_post():
    name = request.form['name']
    password = request.form['password']
    mail = request.form['mail']
    result = access.create_user(name, password, mail)
    if isinstance(result, int):
        session['user_id'] = result  # Enregistrer l'ID de l'utilisateur dans la session
        return redirect('/')
    else:
        return render_template('register.html', error=result)


@app.get('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('home'))


@app.get('/update_user')
@login_required
def update_form():
    user_id = session.get('user_id')
    return render_template('update_user.html', user_id=user_id)


@app.post('/update_user')
@login_required
def update_user_post():
    user_id = session['user_id']
    name = request.form.get('name')
    password = request.form.get('password')
    result = access.update_user(user_id, name, password)
    return result


@app.get('/delete_user')
@login_required
def delete_user_form():
    user_id = session.get('user_id')
    return render_template('delete_user.html', user_id=user_id)


@app.post('/delete_user')
@login_required
def delete_user_post():
    result = access.delete_user()
    return result


@app.get('/new_item')
@login_required
def new_item_form():
    return render_template('new_item.html')


@app.post('/new_item')
@login_required
def new_item_post():
    description = request.form.get('description')
    condition = request.form.get('condition')
    location = request.form.get('location')
    img_file = request.files['img_file']

    # Vérifiez si le fichier téléchargé est autorisé
    if img_file and allowed_file(img_file.filename):
        # Générer le chemin complet du répertoire de téléchargement
        upload_folder_path = os.path.join(app.root_path, app.config['UPLOAD_FOLDER'])

        # Créer le répertoire s'il n'existe pas déjà
        os.makedirs(upload_folder_path, exist_ok=True)

        # Générer un nom de fichier sécurisé pour le fichier téléchargé
        filename = secure_filename(img_file.filename)

        # Enregistrer le fichier dans le répertoire de téléchargement
        img_file.save(os.path.join(upload_folder_path, filename))

        # Construire l'URL de l'image
        img_url = url_for('uploaded_files', filename=filename)

        # Appelez la fonction create_item pour enregistrer les détails de l'article dans la base de données
        result = access.create_item(description, condition, img_url, location)

        return redirect(url_for('home'))
    else:
        return "Erreur : Fichier non autorisé"


@app.route('/uploads/<filename>')
def uploaded_files(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)


@app.get('/delete_item')
@login_required
def delete_item_form():
    item_id = request.args.get('item_id')
    return render_template('delete_item.html', item_id=item_id)


@app.post('/delete_item')
@login_required
def delete_item_post():
    user_id = session.get('user_id')

    # Récupérer l'ID de l'item à supprimer à partir du formulaire
    item_id = access.db_fetch('SELECT id FROM items')

    # Vérifier si l'utilisateur est le propriétaire de l'article
    item_owner = access.get_item_owner(item_id)

    # Vérifier si l'utilisateur est autorisé à supprimer l'article
    if item_owner == user_id:
        result = access.delete_item(item_id)
        return redirect('/')
    else:
        return "Vous n'êtes pas autorisé à supprimer cet article."

@app.get('/contact')
@login_required
def contact_form():
    return render_template('contact.html')

@app.post('/contact')
@login_required
def contacter_proprietaire():
    owner_email = request.form['owner_email']
    owner_id = access.get_item_owner()
    user_email = access.db_fetch()
    message = request.form['message']

   # msg = Message('Intérêt pour le meuble', sender=user_email, recipients=[owner_email])
   # msg.body = message

    try:
      #  mail.send(msg)
        flash('Votre message a été envoyé avec succès au propriétaire du meuble.', 'success')
    except Exception as e:
        flash('Une erreur s\'est produite lors de l\'envoi de l\'e-mail. Veuillez réessayer plus tard.', 'error')

    return redirect(url_for('meubles_disponibles'))


if __name__ == '__main__':
    app.run(debug=True)
